

#include "ruby.h"

VALUE rb_actual_class(VALUE obj) {
    return CLASS_OF(obj);
}

void
Init_actual()
{   
    rb_define_method(rb_cObject, "__actual_class", rb_actual_class, 0);
}    