require 'metaid'
require 'set'
require 'actual'

class Graph
  attr_reader :nodes, :edges, :node_cache
  
  class Node < Struct.new(:name); end
  class Edge < Struct.new(:from, :to, :style); end
  class EdgeStyle < Struct.new(:name); end
  
  def initialize
    @nodes = Set.new
    @edges = Set.new
    @available_styles = [:default, :normal, :ediamond, :onormal, :circle]

    @default_style = edge_style
    @node_cache = {}
  end
  
  def edge(n1, n2, edge_style=nil)
    Edge.new(n1, n2, edge_style||@default_style).tap { |e| @edges << e }
  end
  
  def node(name)
    Node.new(name).tap { |n| @nodes << n }
  end
  
  def cached_obj_node(obj)
    return node_cache[obj] if node_cache.has_key?(obj)
    
    node_cache[obj] = node(obj.inspect)
  end
  
  def edge_style
    EdgeStyle.new(@available_styles.shift)
  end
  
  def print
    puts "digraph ruby {"
    nodes.each do |node|
      puts %Q/"#{node.name}" [shape=box];/
    end
    edges.each do |e|
      puts %Q/"#{e.from.name}" -> "#{e.to.name}" [arrowhead=#{e.style.name}];/
    end
    puts "}"
  end
end

graph = Graph.new

# n1 = graph.node('test')
# n2 = graph.node('test')
# n3 = graph.node('other')
# 
# graph.edge n1,n2
# 
# graph.edge n2,n3
# graph.edge n2,n3
# 
# s = graph.edge_style
# graph.edge n1,n2,s
# 
# graph.print

class Foo
end

foo = Foo.new

styles = [
  [:class, graph.edge_style],
  [:metaclass, graph.edge_style],
  [:superclass, graph.edge_style], 
  [:__actual_class, graph.edge_style]
]

def visit(styles, graph, obj, depth=0)
  from = graph.cached_obj_node(obj)
  
  styles.each do |(method, edge_style)|
    begin
      other = obj.send(method)
      to = graph.cached_obj_node(other)
      
      graph.edge from, to, edge_style
      
      if depth > 0
        visit(styles, graph, other, depth-1)
      end
    rescue => b
      # p b
      $stderr.puts "#{obj.inspect} doesn't seem to have a #{method}..."
    end
  end
end

visit(styles, graph, foo, ARGV.first.to_i)
graph.print